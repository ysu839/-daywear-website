const bagButton = document.querySelector(".bag");

bagButton.addEventListener("click", () => {
  alert("Your bag is empty. Add products soon.");
});
